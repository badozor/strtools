# ==============================================================================
# Title: Empty R Script
# Description: Empty R Script
# Author: Pierre BADY <pierre.bady@free.fr>
# Date: 02/06/11 21:03:35
# Revision: 02/06/11 21:03:35
# Version: 0.1
# Comments: RAS
# License: GPL version 2 or newer
# Copyright (C) 2008  Pierre BADY
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# ==============================================================================

# preparation du package strtools
#  Created: 03/29/08 13:28:19 by bad

source("H:/DepotSVN/strtools/trunk/Rcode/strtools-0.1.R")
package.skeleton("strtools")

############## END #######################


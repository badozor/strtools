PATH=C:\programs\R\R-2.12.1\bin;C:\programs\Rtools\bin;C:\Perl\bin;C:\programs\Rtools\MinGW\bin;C:\programs\Rtools\MinGW\include;C:\programs\MiKTeX 2.7\miktex\bin;C:\programs\Ghostgum\gsview;C:\programs\gs\gs8.53\bin;C:\Program Files\Adobe\Acrobat 5.0\Reader;C:\Program Files\HTML Help Workshop;
R CMD check strtools
R CMD build strtools
R CMD build -binary strtools
R CMD Rd2dvi --pdf strtools

